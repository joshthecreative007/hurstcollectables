#!/usr/bin/env python3
"""
Regenerates data.js from hurstcollectibles-editable-inventory.csv.

Usage:
    python3 scripts/build_data_js.py

Run this from the repo root after editing the CSV (e.g. adding prices,
marking items sold by deleting their row, adding new rows for new stock).
It overwrites data.js in place. Commit + push both files together.

CSV columns expected (header row required):
    sku, series, issue, story_title, publisher, cover_date, edition,
    story_arc, grade, genre, format, upc, price, quantity,
    condition_id, photo_url

Notes:
- price should be a plain number like 12.99 (no $ sign) or left blank.
- Leave price blank to show "Price on request" instead of a Buy Now button.
- sku must be unique per physical copy — if you have two copies of the
  same issue/grade, give them different skus (e.g. append -1 / -2).
- To remove an item from the site, just delete its row.
- To add an item, add a new row with at least sku, series, issue, and
  photo_url filled in.
"""
import csv
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CSV_PATH = ROOT / "hurstcollectables-editable-inventory.csv"
DATA_JS_PATH = ROOT / "data.js"

FIELDS = [
    "sku", "series", "issue", "story_title", "publisher", "cover_date",
    "edition", "story_arc", "grade", "genre", "format", "upc", "price",
    "quantity", "condition_id", "photo_url",
]


def slugify(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")


def main():
    if not CSV_PATH.exists():
        print(f"ERROR: {CSV_PATH} not found.", file=sys.stderr)
        sys.exit(1)

    items = []
    seen_skus = set()
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = [c for c in ["sku", "series", "issue", "photo_url"] if c not in reader.fieldnames]
        if missing:
            print(f"ERROR: CSV is missing required column(s): {missing}", file=sys.stderr)
            sys.exit(1)
        for row_num, row in enumerate(reader, start=2):
            sku = (row.get("sku") or "").strip()
            if not sku:
                print(f"WARNING: row {row_num} has no sku, skipping.", file=sys.stderr)
                continue
            if sku in seen_skus:
                print(f"ERROR: duplicate sku '{sku}' at row {row_num}. "
                      f"Every physical copy needs a unique sku.", file=sys.stderr)
                sys.exit(1)
            seen_skus.add(sku)

            item = {k: (row.get(k) or "").strip() for k in FIELDS}
            item["id"] = item["sku"]
            item["series_slug"] = slugify(item["series"])
            item["listing_type"] = "raw"
            items.append(item)

    with open(DATA_JS_PATH, "w", encoding="utf-8") as f:
        f.write("const INVENTORY = ")
        json.dump(items, f)
        f.write(";")

    print(f"OK: wrote {len(items)} items to {DATA_JS_PATH}")


if __name__ == "__main__":
    main()
