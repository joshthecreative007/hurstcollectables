# Hurst Collectables — hurstcollectables.com

Static site for browsing and buying single-issue comics and slabs.
No backend, no build step — plain HTML/CSS/JS deployed via Netlify,
auto-redeploying on every push to this repo.

## Files

| File | What it is |
|---|---|
| `index.html` | Page structure |
| `styles.css` | Bond-inspired dark theme |
| `app.js` | Search, filters, modal, Buy Now buttons |
| `data.js` | **Generated file** — the full inventory as JS data. Don't hand-edit this. |
| `hurstcollectables-editable-inventory.csv` | **Source of truth for inventory.** Edit this in Excel/Sheets. |
| `scripts/build_data_js.py` | Regenerates `data.js` from the CSV. |

## How to update the site

### Change inventory (add/remove/edit a book, add a price, mark something sold)

1. Open `hurstcollectables-editable-inventory.csv` in Excel or Google Sheets.
2. Make your edits:
   - **Add a book** → add a new row. `sku`, `series`, `issue`, and `photo_url` are the minimum required fields.
   - **Remove a book** (e.g. sold on eBay) → delete its row.
   - **Set a price** → fill in the `price` column with a plain number (e.g. `24.99`, no `$`). Leave blank to show "Price on request" instead of a Buy Now button on the site.
   - **Mark condition/grade changes** → edit the `grade` column.
3. Save/export as CSV (keep the same filename).
4. Run the build script from the repo root:
   ```
   python3 scripts/build_data_js.py
   ```
   This overwrites `data.js` to match the CSV. It will warn you about
   duplicate SKUs or rows missing required fields.
5. Commit and push both the CSV and the regenerated `data.js`:
   ```
   git add hurstcollectables-editable-inventory.csv data.js
   git commit -m "Update inventory"
   git push
   ```
   Netlify picks up the push automatically and the live site updates
   within about a minute — no manual re-upload needed.

If you don't want to run Python locally, share the updated CSV and
have it regenerated for you, then upload the new `data.js` directly
in the GitHub web UI (Add file → Upload files).

### Change the PayPal payout email

Open `app.js`, near the top:
```js
const PAYPAL_BUSINESS_EMAIL = 'placeholder@hurstcollectables.com';
```
Replace with your real PayPal email before taking live orders.

### Change site design/copy

Edit `index.html` (text/structure) or `styles.css` (colors/layout)
directly, then commit and push.

## Hosting

- **Domain:** hurstcollectables.com, registered at GoDaddy.
- **Hosting:** Netlify (free tier), deployed from this GitHub repo.
- Any push to the main branch triggers an automatic Netlify rebuild —
  no manual drag-and-drop upload needed once this is connected.

## eBay

This site is **not synced with eBay** — the two are separate sales
channels. If a book sells on eBay, remove its row from the CSV here
manually (and vice versa) to avoid double-selling the same copy.
